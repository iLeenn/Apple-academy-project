//
//  HomePage.swift
//  FinalProject
// 
//  Created by shatha on 25/01/1445 AH.
//
import SwiftUI

struct HomePage: View {
    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                Image("mg1")
                    .resizable()
                    .frame(width: 250, height: 200)
                    .padding(.top, -21)
                    .padding(.bottom, 50)
                    .padding(.leading, 50)
                
                Button(action: {}) {
                    Text("Read")
                        .font(.title)
                        .padding(.leading)
                        .foregroundColor(Color.black)
                    
                    Image("read")
                        .resizable()
                        .frame(width: 110, height: 80)
                        .padding(.top, 10)
                        .padding(.leading, 143)
                }
//                .buttonStyle(.bordered)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray.opacity(0.5), lineWidth: 2)
                        .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                )
                
                
                
                
                Button(action: {}) {
                    Text("Games")
                        .font(.title)
                        .padding(.leading)
                        .foregroundColor(Color.black)
                    
                    Image("game")
                        .resizable()
                        .frame(width: 110, height: 80)
                        .padding(.top, 10)
                        .padding(.leading, 123)
                }
//                .buttonStyle(.bordered)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray.opacity(0.5), lineWidth: 2)
                        .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                )
                
                
             
                Button(action: {}) {
                    Text("Exercise")
                        .padding(.leading)
                        .font(.title)
                        .foregroundColor(Color.black)
                    
                    Image("Exercise")
                        .resizable()
                        .frame(width: 110, height: 80)
                        .padding(.top, 10)
                        .padding(.leading, 110)
                }
//                .buttonStyle(.bordered)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray.opacity(0.5), lineWidth: 2)
                        .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                )
                
                
                
            }
            
            
            
            
            .navigationTitle("Start ")
        }
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}

