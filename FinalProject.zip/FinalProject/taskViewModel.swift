//
//  taskViewModel.swift
//  FinalProject
//
//  Created by shatha on 25/01/1445 AH.
//

import SwiftUI
import Foundation

class taskViewModel:ObservableObject{
    
    
    @Published var Alltasks: [taskModel] = [
        taskModel(task_img: "image1",task_title: "Exercise 1: Diaphragmatic breathing",task_link: "https://youtu.be/F6tEygVuy1Y?t=25&si=72HPIUIq3wEEz8Pk",checkBox: false),
        
        taskModel(task_img: "image2",task_title: "Exercise 2: Speaking on the exhale",task_link: "https://youtu.be/F6tEygVuy1Y?t=153&si=cGurn9z-IEC-kDqH",checkBox: false),
        taskModel(task_img: "image3",task_title: "Exercise 3: Pacing",task_link:"https://youtu.be/F6tEygVuy1Y?t=217&si=Tb40k_hecIsY45Cs",checkBox: false)
        
        
        
        
    ]
}
    
    
    
