//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by shatha on 23/01/1445 AH.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen1()
        }
    }
}
