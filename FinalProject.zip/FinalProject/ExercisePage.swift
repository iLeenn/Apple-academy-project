//
//  ExercisePage.swift
//  FinalProject
//
//  Created by shatha on 25/01/1445 AH.
//
import SwiftUI

struct ExercisePage: View {
//    @State var ch1 = false
//    @State var ch2 = false
//    @State var ch3 = false
    
    
    let gradient = Gradient(colors:[Color("Color1"),Color("Color2"),Color("Color3"),Color("Color4"),Color("Color5")])
    
    init(){
        UITableView.appearance().backgroundColor = .clear
    }
    @ObservedObject var taskModel = taskViewModel()
    var body : some View {
        
        
        ZStack(){
            
            
            
            LinearGradient(gradient: gradient, startPoint: .bottomLeading, endPoint: .topTrailing).ignoresSafeArea()
            
            
            VStack(alignment: .leading , spacing: -40){
                Text("Exercises").foregroundColor(.black).font(.system(size:40).bold()).padding()
                    .padding(.top, 50)
                
                ZStack{
                    
                    RoundedRectangle(cornerRadius: 47)
                        .fill(.white)
                    
                        .frame(width: 390,alignment: .center).padding(.bottom,-50).padding(.top,60)
                    
                    List() {
                        
                        ForEach(taskModel.Alltasks.indices, id: \.self) { index in
                            let task = taskModel.Alltasks[index]
                            
                            VStack {
                                Text("\(task.task_title)")
                                
                                HStack {
                                    Button {
                                        taskModel.Alltasks[index].checkBox.toggle()
                                        print(taskModel.Alltasks[index].checkBox)
                                    } label: {
                                        Image(systemName: taskModel.Alltasks[index].checkBox ? "checkmark.circle" : "circle")
                                            .resizable()
                                            .frame(width: 20, height: 20)
                                            .foregroundColor(taskModel.Alltasks[index].checkBox ? .green : .black)
                                    }
                                    
                                    Spacer()
                                    
                                    VStack {
                                        Spacer()
                                        
                                        Image("\(task.task_img)")
                                            .resizable()
                                            .frame(width: 200, height: 100)
                                            .cornerRadius(10)
                                            .onTapGesture {
                                                if let url = URL(string: "\(task.task_link)") {
                                                    UIApplication.shared.open(url)
                                                }
                                            }
                                        
                                        Spacer()
                                    }
                                    
                                    Spacer()
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.vertical, 8)
                            .padding(.horizontal, 16)
                        }
                        
                        
                    }
                    .scrollContentBackground(.hidden)
                    .frame(width: 400.0, height: 400.0)
                    .listStyle(.plain)
                    
         
                    
                }
            
                
                
                
                
                
                
                
                
                
            }
            
        }
        
    }
}


struct ExercisePage_Previews: PreviewProvider {
    static var previews: some View {
        ExercisePage()
    }
}
